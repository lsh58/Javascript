
var btnCollapse ;
var heading ; 
var question ;
var body ; 

for () {
    .addEventListener( {
        for () {
            ; // 클릭(heading)하면 다른곳(question)에 있는 active는 모두 사라지고
            ; // 클릭한곳(heading)의 부모(question)에 active 추가하기
            activateBody();
        }
    });
}

function activateBody() {
    for () {
        //active가 없는 모든 내용(body) 는 display=none을 갖고,
    }
    var activePanel ; //active를 갖는 question의 body에 접근
    ; //active가 있는 곳의 내용만 display=block를 갖도록
}

activateBody();

.addEventListener({
    for(){
        ; // (추가) colapse all 을 누르면 전체가 접히게
    }   
});