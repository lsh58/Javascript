
var targetLink = ; //a태그에 접근 (.tab-menu a)
var tabContent = ; //tab-content안의 모든 div에 접근 (#tab-content > div)



for(){
    .addEventListener({
        //a링크 효과 제거    
        //클릭하면 a링크 모든효과 제거 

        var orgTarget ; //a태그 안에 있는 href값에 접근
        var tabTarget ; // href값에 있는 #을 제거한 값 저장

        for(){} // tab-content안에 있는 모든 div의 display를 none으로 저장
        //“#이 제거된 href의값과 이름이 일치하는” div의 display를 block으로 저장 

        for(){} // 모든 a태그에 ‘active’ 클래스값을 제거한 뒤, (for문
        //클릭된 a링크에만 ‘active’클래스값을 추가

    });
}
